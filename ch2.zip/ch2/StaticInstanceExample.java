package ch2;

class A{
	int a;
	static int b;
}

public class StaticInstanceExample {
	public static void main(String[] args) {
		A a = new A();
		System.out.println(a.a);
		System.out.println(a.b); 
		System.out.println(A.b);
	}
}



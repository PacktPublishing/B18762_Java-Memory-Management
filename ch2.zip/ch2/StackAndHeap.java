//package ch2;
//
//class Person {
//	private String name;
//	private int age;
//	
//	Person(String aName, int aAge){
//		name = aName;
//		age  = aAge;
//	}
//	@Override
//	public String toString(){
//		String decoratedName = "My name is "+name + 
//				" and I am "+ age + " years old.";
//		return decoratedName;
//	}
//}
//
//public class StackAndHeap {
//	public static void main(String[] args) {
//		int x=0;
//		Person joeBloggs = new Person("Joe Bloggs", 23);	
//		System.out.println(x);
//		System.out.println(joeBloggs.toString());
//		System.out.println(args.length);
//	}
//}
//
//
//

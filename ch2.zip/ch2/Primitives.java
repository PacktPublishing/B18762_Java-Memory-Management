package ch2;

public class Primitives {

	public static void main(String[] args) {
		
		char c  = 97;  // 'a';
		short s = 2;
		
		c = s; 
		s = c; 
		
		c = (char)s;  
		s = (short)c; 
		c = 4;      
		
	}

}



/*
package ch2;

public class Primitives {

	public static void main(String[] args) {
		
		char c  = 97;  // 'a';
		short s = 2;
		
		c = s; // requires cast
		s = c; // requires cast
		
		c = (char)s;  // cast ok
		s = (short)c; // cast ok
		c = 4;        // compile time constant ok

	}

}
 
 */

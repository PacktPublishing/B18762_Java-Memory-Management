//package ch2;
//
//interface Driveable{}
//
//abstract class Car{}
//class Volvo extends Car implements Driveable{}
//
//public class InterfaceExample {
//	public static void main(String[] args) {
//		Car car; 			
//		car = new Car();	
//		car = new Volvo();	
//		
//		Driveable driveable;				
//		driveable = new Driveable();	
//		driveable = new Volvo();	
//	}
//}
//
//
//

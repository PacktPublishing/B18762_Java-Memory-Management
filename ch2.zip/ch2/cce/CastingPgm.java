package ch2.cce;

interface Shape {
    public void draw();
}
class Triangle implements Shape{
    @Override
    public void draw(){
        System.out.println("Triangle::draw()");
    }
}
class RightAngledTriangle extends Triangle {
    @Override
    public void draw(){
        System.out.println("RightAngledTriangle::draw()");
    }
    public void hypotenuse(){
        System.out.println("RightAngledTriangle::hypotenuse()");
    }
}
public class CastingPgm {
    public static void main(String []args){
        // upcasting
        Triangle t = new RightAngledTriangle();
        t.draw();
//        t.hypotenuse();
        
        RightAngledTriangle r  = new RightAngledTriangle();
        r.draw();
        r.hypotenuse();

        // downcasting
  //      RightAngledTriangle r2 = new Triangle(); 
        RightAngledTriangle r3 = (RightAngledTriangle)new Triangle();   
        r3.hypotenuse();
    }
}





//package ch2.cce;
//
//public class CastingPgm {
//    public static void main(String []args){
//        upcasting();
//        downcasting();
//    }
//    public static void upcasting(){
//        Triangle t = new RightAngledTriangle();
//        t.draw();   	// RightAngledTriangle::draw
//        
//        Triangle t1             = new Triangle();
//        RightAngledTriangle r1  = new RightAngledTriangle();
//        t1.draw();  	// Triangle::draw()
//        r1.draw();  	// RightAngledTriangle::draw
//        t1 = r1;
//        t1.draw();  	// RightAngledTriangle::draw
//        //t1.area();  	// compiler error: "cannot find symbol"
//
//        // upcasting to the interface
//        Shape s = new Triangle();
//        s.draw();   	// Triangle::draw()
//        s=r1;
//        s.draw();   	// RightAngledTriangle::draw
//        
//        progToTheInterface(new Triangle());             // Triangle::draw()
//        progToTheInterface(new RightAngledTriangle());  // RightAngledTriangle::draw
//    }
//    public static void progToTheInterface(Shape s){
//        s.draw();
//    }
//    public static void downcasting(){
//        Triangle t             = new Triangle();
//        RightAngledTriangle r  = new RightAngledTriangle();
//        
//        t=r; // upcasting
//        t.draw();  		// RightAngledTriangle::draw()
//        //t.area();  		// compiler error: "cannot find symbol"
//
//        Triangle t1             = new Triangle();
//        RightAngledTriangle r1  = new RightAngledTriangle();
//        //r1=t1;  // compiler error: "incompatible types: required RightAngledTriangle; found Triangle"
//        
//        //r1=(RightAngledTriangle)t1; // downcasting - requires a cast; ClassCastException at runtime
//        
//        /*
//         * "RightAngledTriangle r2 = new Triangle();" results in a compiler error "incompatible types"
//         * so I cast it:
//         * RightAngledTriangle r2 = (RightAngledTriangle)new Triangle();
//         * and the compiler is satisfied (as both are in the same inheritance hierarchy).
//         * However, as the object reference being cast is of a superclass (Triangle),
//         * it results in a ClassCastException as runtime...
//         * NB: a RightAngledTriangle reference can point to a RightAngledTriangle object (or any subclass of
//         * RightAngledTriangle) but NOT a Triangle object (ClassCastException at runtime).
//         * This is because a RightAngledTriangle) reference would know of an area() that the object to which it is
//         * referring has no knowledge of (as a Triangle object has no area() method)�
//         */
//        Triangle t2 = new RightAngledTriangle();    	// OK - upcasting; a RightAngledTriangle is a Triangle
//        
//        //RightAngledTriangle r2 = new Triangle(); // compiler error: a Triangle is not necessarily a RAT
////        RightAngledTriangle r2 = (RightAngledTriangle)new Triangle();    // ClassCastException
//        
//        // A Triangle reference can talk to a Triangle object or any subclass of Triangle.
//        // A RightAngledTriangle reference can talk to a RightAngledTriangle object or any
//        // subclass of RightAngledTriangle.
//        // A RightAngledTriangle reference ***cannot*** talk to a Triangle object!! Even with a 
//        // (down)cast...
//        // Hence the exception creating "r2" above...
//        // *** NB *** The object you are downcasting from must of the same type or a subclass 
//        // of the type that you are casting to. This is because a reference (at the end of the day) 
//        // can only work with objects of its own type and its subclasses...
//        
//    	Triangle t5 = new RightAngledTriangle();
//    	t5.draw();								// RightAngledTriangle::draw()
//    	RightAngledTriangle r5 = (RightAngledTriangle)t5; 	// ok, as t5 refers to a RightAngledTriangle object, 
//    										// thus r5.area() will work on next line 
//    	r5.area();								// RightAngledTriangle::area()
//
//    	Triangle t6 = new Triangle();
//    	t6.draw();								// Triangle::draw()
//    	RightAngledTriangle r6 = (RightAngledTriangle)t6; 	// ClassCastException - Triangle obj cannot be cast to RAT
//    	r6.area();								// not ok, as t6 refers to a Triangle object and thus,
//    										// r6.area would fail on the next line
//    }
//}
//*/
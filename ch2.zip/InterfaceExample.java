package ch2;

interface Driveable{}

abstract class Car{}
class Volvo extends Car implements Driveable{}

public class InterfaceExample {
	public static void main(String[] args) {
		Car car; 			
//		car = new Car();	
		car = new Volvo();	
		System.out.println(car.toString());
		
		Driveable driveable;				
//		driveable = new Driveable();	
		driveable = new Volvo();	
		System.out.println(driveable.toString());
	}
}




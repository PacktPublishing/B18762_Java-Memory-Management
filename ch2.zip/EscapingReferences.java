package ch2;

class Person {
	private StringBuilder name;

	Person(StringBuilder name) {
		this.name = new StringBuilder(name.toString());
	}
	public StringBuilder getName() {
		return new StringBuilder(name.toString());
	}
}

public class EscapingReferences {
	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder("Dan");
		Person p = new Person(sb);
		sb.append("Dan");
		System.out.println(p.getName()); // Dan

		StringBuilder sb2 = p.getName();
		sb2.append("Dan");
		System.out.println(p.getName()); // Dan 
	}
}


// the issue:
//class Person {
//	private StringBuilder name;
//
//	Person(StringBuilder name) {
//		this.name = name;
//	}
//	public StringBuilder getName() {
//		return name;
//	}
//}
//
//public class EscapingReferences {
//	public static void main(String[] args) {
//		StringBuilder sb = new StringBuilder("Dan");
//		Person p = new Person(sb);
//		sb.append("Dan");
//		System.out.println(p.getName()); // DanDan
//
//		StringBuilder sb2 = p.getName();
//		sb2.append("Dan");
//		System.out.println(p.getName()); // DanDanDan
//	}
//}

// the solution:
//class Person {
//	private StringBuilder name;
//
//	Person(StringBuilder name){
//		this.name = new StringBuilder(name.toString());
//	}
//	public StringBuilder getName() {
//		return new StringBuilder(name.toString());
//	}
//}
//
//public class EscapingReferences {
//	public static void main(String[] args) {
//		StringBuilder sb = new StringBuilder("Dan");
//		Person p = new Person(sb);
//		sb.append("Dan");
//		System.out.println(p.getName()); // Dan
//		
//		StringBuilder sb2 = p.getName();
//		sb2.append("Dan");
//		System.out.println(p.getName()); // Dan
//	}
//}


/*
class Person{
 private StringBuilder s = 
         new StringBuilder("Dan"); // mutable
 public void printName() {System.out.println(s);}
 public StringBuilder getName() {
     // returning a reference to the 
     // COPY of the mutable object - encapsulation
     return new StringBuilder(s.toString());
 }
}
public class AdvancedEncapsulation {
 public static void main(String[] args) {
     Person p = new Person();
     StringBuilder s2 = p.getName();
     // s and s2 now refer to different StringBuilder 
     // objects and thus, AdvancedEncapsulation is
     // unable to change the private StringBuilder
     // object in Person
     s2.append("Dan"); 
     System.out.println(s2); // DanDan
     p.printName();          // Dan
 }
}
*/

//class Person {
//	private List list = new ArrayList<>(); // mutable
//
//	public void printList() {
//		System.out.println(list);
//	}
//
//	public List getList() {
//		return new ArrayList<>(list);// encapsulation
////     return list;// not encapsulation
//	}
//}
//
//public class EscapingReferences {
//	public static void main(String[] args) {
//		Person p = new Person();
//		List l = p.getList();
//		l.add("test");
//		p.printList();
//	}
//}
